package org.rpi.rpinfo;

public class ResultsCache {
	public ResultsCache(){
	}
}
